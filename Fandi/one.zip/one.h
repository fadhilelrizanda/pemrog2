#include <iostream>
using namespace std;

#ifndef ONE_H
#define ONE_H

class One
{
public:
    int x, y;
    One(int a, int b);
    int getX();
    int getY();
};

#endif