#include <iostream>
#include "point.h"
using namespace std;

Point::Point(int a, int b)
{
    x = a;
    y = b;
}