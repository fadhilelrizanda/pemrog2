// Kelompok 9 \n
// 1. M.Aldi Fajar 1910953011 \n
// 2. Tryfandy Sarfaldi 1910952001 \n
// 3. Ari Andrian 1910953017\n
// 4. Taufik Reza 1910951024 \n \n \n

#include <iostream>
#include "one.h"
#include <conio.h>
using namespace std;

int main()
{
    cout << "Kelompok 9 " << endl;
    cout << "1. M.Aldi Fajar 1910953011 " << endl;
    cout << "2. Tryfandy Sarfaldi 1910952001" << endl;
    cout << "3. Ari Andrian 1910953017" << endl;
    cout << "4. Taufik Reza 1910951024 " << endl;
    cout << endl;
    cout << endl;
    cout << "Kelompok 9 " << endl;
    One fandi(10, 12);
    cout << "Value X : " << fandi.getX() << endl;
    cout << "Value Y : " << fandi.getY() << endl;
    getch();
}