// Kelompok 9
// 1. M.Aldi Fajar 1910953011
// 2. Tryfandy Sarfaldi 1910952001
// 3. Ari Andrian 1910953017
// 4. Taufik Reza 1910951024

#include <iostream>
using namespace std;

#ifndef ONE_H
#define ONE_H

class One
{
public:
    int x, y;
    One(int a, int b);
    int getX();
    int getY();
};

#endif